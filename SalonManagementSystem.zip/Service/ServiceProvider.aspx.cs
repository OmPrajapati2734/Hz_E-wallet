﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Service_ServiceProvider : System.Web.UI.Page
{
    BranchService s = new BranchService();
    DataClassesDataContext dbc = new DataClassesDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["open"] != null)
        {
            if (!IsPostBack)
            {
                foreach (var b in s.get_serviceprovidemasterlistby_id(Convert.ToInt64(Request.QueryString["open"].ToString())))
                {
                    txt_address.Text = b.Address;
                    txt_contact.Text = b.ContactNumber;
                    txt_dob.Text = Convert.ToDateTime(b.DateOfBirth).ToString();
                    txt_email.Text = b.Email;
                    txt_emergencycontact.Text = b.EmergencyContactNo;
                    txt_emergencycontactperson.Text = b.EmergencyContactPerson;
                    txt_gender.Text = b.Gender;
                    txt_joindate.Text = Convert.ToDateTime(b.DateOfJoinning).ToString();
                    txt_monthlysalary.Text = Convert.ToDecimal(b.MonthlySalary).ToString();
                    txt_password.Text = b.Password;
                    txt_photo.Text = b.IdProofPhoto;
                    txt_productcomission.Text = Convert.ToDecimal(b.ProductComission).ToString();
                    txt_providername.Text = b.ProviderName;
                    txt_servicecomission.Text = Convert.ToDecimal(b.ServiceComission).ToString();
                    txt_providername.Text = b.ProviderName;
                    txt_serviceproviderphoto.Text = b.ServiceProviderPhoto;
                    txt_username.Text = b.Username;
                    txt_whe.Text = Convert.ToDateTime(b.WorkingHourEnd).ToString();
                    txt_whs.Text = Convert.ToDateTime(b.WorkingHourStart).ToString();
                    Chk_status.Checked = Convert.ToBoolean(b.Status);

                }
            }
        }


        if (Request.QueryString["delete"] != null)
        {
            int i = s.delete_serviceprovidermaster(Convert.ToInt64(Request.QueryString["delete"].ToString()));
            if (i == 1)
            {
                Response.Redirect("ServiceProvider.aspx?action=delete");
            }
            else
            {
                Response.Redirect("#?action=error");
            }
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            if (Request.QueryString["open"] != null)
            {
                Response.Write("<script>alert('" + Request.QueryString["open"].ToString() + "')</script>");
                int i = s.update_serviceprovidermaster(Convert.ToInt64(Request.QueryString["open"].ToString()),txt_providername.Text,Convert.ToDecimal(txt_servicecomission.Text),Convert.ToDecimal(txt_productcomission.Text),Convert.ToDateTime(txt_dob.Text),Convert.ToDateTime(txt_whs.Text),Convert.ToDateTime(txt_whe.Text),Convert.ToDecimal(txt_monthlysalary.Text),txt_serviceprovidertype.SelectedValue,txt_contact.Text,txt_email.Text,txt_emergencycontact.Text,txt_emergencycontactperson.Text,txt_address.Text,txt_username.Text,txt_password.Text,txt_gender.SelectedValue,Convert.ToDateTime(txt_joindate.Text),txt_photo.Text,txt_serviceproviderphoto.Text,Convert.ToBoolean(Chk_status.Checked),1,DateTime.Now,DateTime.Now);
                if (i == 1)
                {
                    Response.Redirect("ServiceProvider.aspx?action=update");
                }
                else
                {
                    Response.Redirect("#?action=error");
                }
            }
            else
            {
                int i = s.serviceprovidermaster_insert(txt_providername.Text, Convert.ToDecimal(txt_servicecomission.Text), Convert.ToDecimal(txt_productcomission.Text), Convert.ToDateTime(txt_dob.Text),Convert.ToDateTime(txt_whe.Text),Convert.ToDateTime(txt_whs.Text), Convert.ToDecimal(txt_monthlysalary.Text), txt_serviceprovidertype.SelectedValue, txt_contact.Text, txt_email.Text, txt_emergencycontact.Text, txt_emergencycontactperson.Text, txt_address.Text, txt_username.Text, txt_password.Text, txt_gender.SelectedValue, Convert.ToDateTime(txt_joindate.Text), txt_photo.Text, txt_serviceproviderphoto.Text, Convert.ToBoolean(Chk_status.Checked), 1, DateTime.Now, DateTime.Now);
                if (i == 1)
                {
                    Response.Redirect("ServiceProvider.aspx?action=Saved");
                }
                else
                {
                    Response.Redirect("#?action=error");
                }
            }
        }
        catch
        {
        }
    }
}