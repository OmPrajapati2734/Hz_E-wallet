﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Service_ServiceProviderList : System.Web.UI.Page
{
    BranchService s = new BranchService();
    DataClassesDataContext dbc = new DataClassesDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        ListView1.DataSource = (from c in dbc.tbl_ServiceProviderMasters
                                select new
                                {
                                    c.Address,
                                    c.BranchId,
                                    c.ContactNumber,
                                    c.CreatedAt,
                                    c.DateOfBirth,
                                    c.DateOfJoinning,
                                    c.Email,
                                    c.EmergencyContactNo,
                                    c.EmergencyContactPerson,
                                    c.Gender,
                                    c.Id,
                                    c.IdProofPhoto,
                                    c.ModifiedAt,
                                    c.MonthlySalary,
                                    c.Password,
                                    c.ProductComission,
                                    c.ProviderName,
                                    c.ServiceComission,
                                    c.ServiceProviderPhoto,
                                    c.ServiceProviderType,
                                    c.Status,
                                    c.Username,
                                    c.WorkingHourEnd,
                                    c.WorkingHourStart
                                }).ToList();
        ListView1.DataBind();
    }
}