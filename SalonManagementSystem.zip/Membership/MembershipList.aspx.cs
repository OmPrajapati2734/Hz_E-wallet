﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Membership_MembershipList : System.Web.UI.Page
{
    BranchService s = new BranchService();
    DataClassesDataContext dbc = new DataClassesDataContext();
    protected void Page_Load(object sender, EventArgs e)
    {
        ListView1.DataSource = (from c in dbc.tbl_MembershipMasters
                                select new
                                {
                                    c.BranchId,
                                    c.CreatedAt,
                                    c.DiscountOnPackage,
                                    c.DiscountOnPackageType,
                                    c.DiscountOnProduct,
                                    c.DiscountOnProductType,
                                    c.DiscountOnService,
                                    c.DiscountOnServiceType,
                                    c.Duration,
                                    c.Id,
                                    c.MembershipPrice,
                                    c.MembershipType,
                                    c.MinimumBillAmount,
                                    c.MinimumRewardPoint,
                                    c.ModifiedAt,
                                    c.RewardPointBoost,
                                    c.RewardPointOnPurchase,
                                    c.Status
                                }).ToList();
        ListView1.DataBind();

        
    }
}